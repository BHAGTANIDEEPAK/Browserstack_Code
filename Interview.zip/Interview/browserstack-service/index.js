import express from 'express';
import open from 'open';
import session from 'express-session';
import useragent from 'express-useragent';
import fs from 'fs';



import {exec} from 'child_process';

const app = express();

const port = 3000;


app.get('/', (req, res) => {
    fs.unlinkSync("D:\\OneDrive\\Desktop\\Interview\\browserstack-service\\test.txt");
    res.send('Starting the server');

});

//For starting the browser
app.get('/start',(req,res)=>{
    const browser = req.query.browser;

    const url = req.query.url;

    console.log("Browser: ",browser);
    console.log("URL: ",url);

    if(browser === "microsoft-edge"){
        exec(`start microsoft-edge:${url}`);
        res.send("Opening Chrome Browser");
    }
})

//For closing the browser
app.get('/close',(req,res)=>{
    const browser = req.query.browser;

    console.log("Browser:",browser);

    if(browser.trim() === " microsoft-edge"){
        // exec(`taskkill /im msedge.exe /f`);
        exec(`taskkill /f /im msedge.exe`).stdout;
        res.send("Closing Browser");
    }
});




//Cleanup the storage 
app.get('/cleanup',(req,res)=>{
    const browser = req.query.browser;
    if(browser === "chorme"){
        // req.session.destroy();
        // res.send("Cleanup Done");
        // res.send(`
        //     <script>
        //       sessionStorage.clear();
        //     </script>
        //   `);
        var filepath = 'c:\\Users\\HP\AppData\\Local\\Google\\Chrome\\User Data\\Profile 1\\Cache'
        fs.unlinkSync(filepath);
        res.send("Cleanup Done");
    }
    // res.send("Cleanup Done");
});

app.get('/geturl',(req,res)=>{
    const agent = useragent.parse(req.headers['user-agent']);
    const browserName = agent.toAgent();
    const currentUrl = `${req.protocol}://${req.get('host')}${req.originalUrl}`;
    res.send(`
      <p>Browser: ${browserName}</p>
      <p>URL: ${currentUrl}</p>
    `);

});


app.listen(port,()=>{
    console.log("Server Running");
})

